/*
Team Alpha Omega
SFISTA implementation at Spark
*/
// import libraries --------------------------------------------------------------------------------------
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.util.MLUtils
import org.apache.spark.mllib.linalg.distributed.{BlockMatrix, CoordinateMatrix, MatrixEntry}
import scala.io.Source
import org.apache.spark.rdd.RDD

// manually read data and create separate matrices for label and features --------------------------------
var i = 0
val filename = "sample_libsvm_data.txt"
var thisSeq = Seq[MatrixEntry]()
var labelSeq = Seq[MatrixEntry]()

for (line <- Source.fromFile(filename).getLines) 
{
		val items = line.split(' ')
		val label = items.head.toDouble
		val thisLabelEntry = MatrixEntry(i, 0, label)
		labelSeq = labelSeq :+ thisLabelEntry

		for (para <- items.tail)
		{
			val indexAndValue = para.split(':')
			val index = indexAndValue(0).toInt - 1 // Convert 1-based indices to 0-based.
			val value = indexAndValue(1).toDouble
			val thisEntry = MatrixEntry(i, index, value)
			thisSeq = thisSeq :+ thisEntry
		}
		i = i + 1
}
// -------------------------------------------------------------------------------------------------------
val numPar = 4	// number of partitions for RDDs
val numFeatures = 8	// number of features

val entries = sc.parallelize(thisSeq)		// create RDD of MatrixEntry of features
val labelEntries = sc.parallelize(labelSeq)	// create RDD of MatrixEntry of labels

// var productEntries : RDD[MatrixEntry] = null

//initialize iterators
val t = 100
val s = 1
var p = 0
var q = 0

val tick = System.currentTimeMillis()	// get start time

// Main algorithm loops -------------------------------------------------------------------------------------
for ( p <- 0 to t/s )
{
	for ( q <- 0 to s )
	{	
		// randomized sampling of data from the RDDs --------------------------------------------------------
		var samples = entries.sample(false, 0.2, 1L).collect()
		var sampleRDD = sc.parallelize(samples, numPar)

		var labelSamples = labelEntries.sample(false, 0.2, 1L).collect()
		var labelSampleRDD = sc.parallelize(labelSamples, numPar)

		// create two temporary CoordinateMatrix
		var coordX: CoordinateMatrix = new CoordinateMatrix(sampleRDD)
		// var coordY: CoordinateMatrix = new CoordinateMatrix(labelSampleRDD)
		var coordY: CoordinateMatrix = coordX.transpose

		// create RDD of MatrixEntry from CoordinateMatrix
		var rddX  = coordX.entries.map({ case MatrixEntry(i, j, v) => (j, (i, v)) })
		var rddXT = coordY.entries.map({ case MatrixEntry(j, k, w) => (j, (k, w)) })

		// get the products of the two matrices
		var productEntries = rddX.join(rddXT).map({ case (_, ((i, v), (k, w))) => ((i,k), (v * w)) }).reduceByKey(_ + _).map({ case ((i, k), sum) => MatrixEntry(i, k, sum) })
		
		// collect the data as a demonstration of action
		productEntries.collect()
	}
	
	// optionally create final CoordinateMatrix or LocalMatrix --------------------------------------------
	// var productEntriesRDD = sc.parallelize(productEntries) // productEntries is Array of MatrixEntry
	// var mat = new CoordinateMatrix(productEntries)
	// var X: BlockMatrix = mat.toBlockMatrix().cache()
	// var local2 = X.toLocalMatrix()
	// -----------------------------------------------------------------------------------------------------

}

// get final time and calculate total time of execution
val tock = System.currentTimeMillis()
println("Elapsed time: " + (tock - tick)/1000F + " seconds")