Name - Alpha Omega
Date - December 11th

Files -
	1. SFISTA.scala : scala file with code for SFISTA algorithm
	2. CA-SFISTA.scala : scala file with code for CA-SFISTA algorithm
	3. sample_libsvm_data.txt : input data file with 'iris' data set, 150 training data, 4 features

Steps to run code:
	1. copy all three files mentioned above to Spark / bin folder
	2. at terminal, run the Spark-shell command to open the Scala shell for Spark
	3. use these command to run files :
		:load SFISTA.scala 
		:load CA-SFISTA.scala 